class Calculator:

    # A function that adds two numbers
    def add(a, b):
        return a + b

    # A function that subtracts two numbers
    def subtract(a, b):
        return a - b

    # A function that multiplies two numbers
    def multiply(a, b):
        return a * b

    # A function that divides two numbers
    def divide(a, b):
        return a / b
